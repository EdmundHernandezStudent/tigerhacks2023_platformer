gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDPeter_9595LorreObjects1= [];
gdjs.Untitled_32sceneCode.GDPeter_9595LorreObjects2= [];
gdjs.Untitled_32sceneCode.GDplayerObjects1= [];
gdjs.Untitled_32sceneCode.GDplayerObjects2= [];
gdjs.Untitled_32sceneCode.GDlandscapeObjects1= [];
gdjs.Untitled_32sceneCode.GDlandscapeObjects2= [];
gdjs.Untitled_32sceneCode.GDcollObjects1= [];
gdjs.Untitled_32sceneCode.GDcollObjects2= [];
gdjs.Untitled_32sceneCode.GDHouseObjects1= [];
gdjs.Untitled_32sceneCode.GDHouseObjects2= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDCloudObjects1= [];
gdjs.Untitled_32sceneCode.GDCloudObjects2= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDPeter_9595LorreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPeter_9595LorreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDlandscapeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDlandscapeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcollObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcollObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHouseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHouseObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCloudObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCloudObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
